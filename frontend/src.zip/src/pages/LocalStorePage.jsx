import LocalStore from "../components/LocalStore"

export default function LocalStorePage() {
  return (
    <div className="page-container">
      <LocalStore />
    </div>
  )
}

