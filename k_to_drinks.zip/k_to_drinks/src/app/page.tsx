"use client"

import MapLocationPicker from "../components/common/MapLocationPicker"

export default function SyntheticV0PageForDeployment() {
  return <MapLocationPicker />
}