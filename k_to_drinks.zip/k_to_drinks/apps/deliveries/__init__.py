default_app_config = 'apps.deliveries.apps.DeliveriesConfig'

