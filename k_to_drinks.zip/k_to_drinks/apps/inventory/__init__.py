default_app_config = 'apps.inventory.apps.InventoryConfig'

