from django.apps import AppConfig


class InventoryConfig(AppConfig):
    name = 'apps.inventory'
    verbose_name = 'Inventory'

