default_app_config = 'apps.base.apps.BaseConfig'

