from django.apps import AppConfig


class BaseConfig(AppConfig):
    name = 'apps.base'
    verbose_name = 'Base'

