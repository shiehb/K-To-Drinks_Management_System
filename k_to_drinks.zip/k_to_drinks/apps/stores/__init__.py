default_app_config = 'apps.stores.apps.StoresConfig'

