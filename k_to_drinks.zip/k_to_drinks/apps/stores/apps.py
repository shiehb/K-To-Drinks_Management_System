from django.apps import AppConfig


class StoresConfig(AppConfig):
    name = 'apps.stores'
    verbose_name = 'Stores'

