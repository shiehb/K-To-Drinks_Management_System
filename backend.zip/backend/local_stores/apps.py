from django.apps import AppConfig

class LocalStoresConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'local_stores'